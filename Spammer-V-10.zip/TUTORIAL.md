#### Setting Us Is Just Simple | Before Beigning The Code Credits To STORM™#7465
There Is A Video Tutorial Availabe. | [Click Here To View It](https://discord.gg/DZHAZGyQTq) |

# Setting Up The Token
1. Make Sure It's An **Alt Account Just For Spamming**.

2. Get The Token By Seeing This Video. | [Click Here For The Video](https://www.youtube.com/watch?v=3qzpmTIQ-Gs) |

3. After Getting The Token Add A Secret In The Repel It Fine And The KEY Should Be Named _'user_token'_ And The Value Should Be The _'Account Token'_.

# Setting Up The Spam
1. Make A Channel And Name It Spam.
2. Add A Secret In The Repel It Fine And The KEY Should Be Named _'spam_id'_ And The Value Should Be The _'Spam Channel ID'_.

# More Help 

More More Help You Can Contact SOHAM#6212 Or STORM™#7465

You Can Join Our Discord server | [Click Here To Join The Discord Server](https://discord.gg/DZHAZGyQTq) |


### That's All Just Run The Code. And Happy Spawning .